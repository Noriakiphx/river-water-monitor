import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { History, CheckCircle, XCircle, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { ja } from 'date-fns/locale';

export default function NotificationHistory() {
  const { user } = useAuth();
  const [logs, setLogs] = useState([]);
  const [stations, setStations] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    const [logData, stationData] = await Promise.all([
      base44.entities.NotificationLog.filter({ userId: user.id }),
      base44.entities.Station.list('-created_date', 200),
    ]);
    const sorted = logData.sort((a, b) => new Date(b.sentAt || b.created_date) - new Date(a.sentAt || a.created_date));
    setLogs(sorted);
    setStations(Object.fromEntries(stationData.map(s => [s.id, s])));
    setLoading(false);
  };

  const statusIcon = (status) => {
    if (status === 'sent') return <CheckCircle size={16} className="text-green-500" />;
    if (status === 'failed') return <XCircle size={16} className="text-red-500" />;
    return <Clock size={16} className="text-gray-400" />;
  };

  const statusLabel = (status) => {
    if (status === 'sent') return { text: '送信済', color: 'text-green-600 bg-green-50' };
    if (status === 'failed') return { text: '失敗', color: 'text-red-600 bg-red-50' };
    return { text: '保留中', color: 'text-gray-600 bg-gray-100' };
  };

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      <h1 className="text-xl font-bold text-gray-900">通知履歴</h1>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
        </div>
      ) : logs.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
          <History size={40} className="text-gray-300 mx-auto mb-2" />
          <p className="text-gray-500 text-sm">通知履歴はありません</p>
        </div>
      ) : (
        <div className="space-y-3">
          {logs.map(log => {
            const s = stations[log.stationId];
            const sl = statusLabel(log.status);
            const date = log.sentAt || log.created_date;
            return (
              <div key={log.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {statusIcon(log.status)}
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${sl.color}`}>
                        {sl.text}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-gray-900 mt-1">{s?.stationName || '不明な観測所'}</p>
                    <p className="text-xs text-blue-600">{s?.riverName}</p>
                    <p className="text-sm text-gray-700 mt-2">{log.message}</p>
                    {log.errorMessage && (
                      <p className="text-xs text-red-500 mt-1">エラー: {log.errorMessage}</p>
                    )}
                  </div>
                  <div className="text-right ml-3">
                    <p className="text-xs text-gray-400">
                      {date ? format(new Date(date), 'MM/dd HH:mm', { locale: ja }) : '--'}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}