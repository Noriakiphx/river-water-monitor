import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import StationCard from '@/components/StationCard';
import { Bell, Star, AlertTriangle, Activity } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [stations, setStations] = useState([]);
  const [latestLevels, setLatestLevels] = useState({});
  const [watchRules, setWatchRules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    const [favs, allStations, rules, logs] = await Promise.all([
      base44.entities.FavoriteStation.filter({ userId: user.id }),
      base44.entities.Station.list('-created_date', 100),
      base44.entities.WatchRule.filter({ userId: user.id }),
      base44.entities.WaterLevelLog.list('-observedAt', 500),
    ]);
    setFavorites(favs);
    setStations(allStations);
    setWatchRules(rules);

    // Build latest level map per station
    const levelMap = {};
    logs.forEach(log => {
      if (!levelMap[log.stationId]) levelMap[log.stationId] = log.waterLevel;
    });
    setLatestLevels(levelMap);
    setLoading(false);
  };

  const toggleFavorite = async (station) => {
    const existing = favorites.find(f => f.stationId === station.id);
    if (existing) {
      await base44.entities.FavoriteStation.delete(existing.id);
      setFavorites(prev => prev.filter(f => f.id !== existing.id));
    } else {
      const fav = await base44.entities.FavoriteStation.create({ userId: user.id, stationId: station.id });
      setFavorites(prev => [...prev, fav]);
    }
  };

  const favStationIds = new Set(favorites.map(f => f.stationId));
  const favStations = stations.filter(s => favStationIds.has(s.id));

  // Alert stations (above warning level)
  const alertStations = stations.filter(s => {
    const level = latestLevels[s.id];
    return level != null && s.warningLevel != null && level >= s.warningLevel;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 md:pb-6 md:ml-48">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-5 text-white">
        <h1 className="text-xl font-bold">こんにちは、{user?.full_name || 'ユーザー'}さん</h1>
        <p className="text-blue-100 text-sm mt-1">河川水位をリアルタイムで監視しています</p>
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-white/20 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold">{favStations.length}</p>
            <p className="text-xs text-blue-100">お気に入り</p>
          </div>
          <div className="bg-white/20 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold">{watchRules.filter(r => r.enabled).length}</p>
            <p className="text-xs text-blue-100">有効な通知</p>
          </div>
          <div className="bg-white/20 rounded-xl p-3 text-center">
            <p className={`text-2xl font-bold ${alertStations.length > 0 ? 'text-yellow-300' : ''}`}>
              {alertStations.length}
            </p>
            <p className="text-xs text-blue-100">警戒中</p>
          </div>
        </div>
      </div>

      {/* Alerts */}
      {alertStations.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={18} className="text-orange-500" />
            <h2 className="font-semibold text-gray-800">警戒情報</h2>
          </div>
          <div className="space-y-3">
            {alertStations.slice(0, 3).map(s => (
              <StationCard
                key={s.id}
                station={s}
                currentLevel={latestLevels[s.id]}
                isFavorite={favStationIds.has(s.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        </div>
      )}

      {/* Favorites */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Star size={18} className="text-yellow-500" />
            <h2 className="font-semibold text-gray-800">お気に入り観測所</h2>
          </div>
          <Link to="/search" className="text-sm text-blue-600">追加する →</Link>
        </div>
        {favStations.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-8 text-center">
            <Star size={32} className="text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">観測所をお気に入りに追加しましょう</p>
            <Link to="/search" className="mt-3 inline-block bg-blue-600 text-white text-sm px-4 py-2 rounded-full">
              観測所を探す
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {favStations.map(s => (
              <StationCard
                key={s.id}
                station={s}
                currentLevel={latestLevels[s.id]}
                isFavorite={true}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        )}
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 gap-3">
        <Link to="/alerts" className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
            <Bell size={20} className="text-blue-600" />
          </div>
          <div>
            <p className="font-medium text-sm text-gray-800">通知設定</p>
            <p className="text-xs text-gray-500">{watchRules.length}件の設定</p>
          </div>
        </Link>
        <Link to="/history" className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex items-center gap-3">
          <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center">
            <Activity size={20} className="text-green-600" />
          </div>
          <div>
            <p className="font-medium text-sm text-gray-800">通知履歴</p>
            <p className="text-xs text-gray-500">過去の通知を確認</p>
          </div>
        </Link>
      </div>
    </div>
  );
}