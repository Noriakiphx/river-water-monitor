import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Link2, CheckCircle, AlertCircle, Copy, ExternalLink } from 'lucide-react';

export default function LineIntegration() {
  const { user } = useAuth();
  const [lineLinked, setLineLinked] = useState(false);
  const [lineUserId, setLineUserId] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [inputId, setInputId] = useState('');
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (user) {
      setLineLinked(!!user.lineLinked);
      setLineUserId(user.lineUserId || '');
      setInputId(user.lineUserId || '');
    }
  }, [user]);

  const handleSave = async () => {
    setSaving(true);
    await base44.auth.updateMe({ lineUserId: inputId, lineLinked: !!inputId });
    setLineUserId(inputId);
    setLineLinked(!!inputId);
    setEditMode(false);
    setSaving(false);
  };

  const handleDisconnect = async () => {
    if (!confirm('LINE連携を解除しますか？')) return;
    await base44.auth.updateMe({ lineUserId: '', lineLinked: false });
    setLineUserId('');
    setLineLinked(false);
    setInputId('');
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      <h1 className="text-xl font-bold text-gray-900">LINE連携</h1>

      {/* Status card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${lineLinked ? 'bg-green-50' : 'bg-gray-100'}`}>
            💬
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">LINE通知</h2>
            <div className="flex items-center gap-1 mt-0.5">
              {lineLinked ? (
                <>
                  <CheckCircle size={14} className="text-green-500" />
                  <span className="text-sm text-green-600">連携済み</span>
                </>
              ) : (
                <>
                  <AlertCircle size={14} className="text-gray-400" />
                  <span className="text-sm text-gray-500">未連携</span>
                </>
              )}
            </div>
          </div>
        </div>

        {lineLinked && !editMode && (
          <div className="bg-green-50 rounded-lg p-3 mb-4">
            <p className="text-xs text-green-700 mb-1">LINE User ID</p>
            <div className="flex items-center gap-2">
              <p className="text-sm font-mono text-green-900 flex-1 truncate">{lineUserId}</p>
              <button onClick={() => copyToClipboard(lineUserId)} className="p-1">
                {copied ? <CheckCircle size={16} className="text-green-600" /> : <Copy size={16} className="text-gray-400" />}
              </button>
            </div>
          </div>
        )}

        {editMode ? (
          <div className="space-y-3">
            <div>
              <label className="text-sm text-gray-600 block mb-1">LINE User ID</label>
              <input
                type="text"
                value={inputId}
                onChange={e => setInputId(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:outline-none font-mono"
                placeholder="Uxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleSave}
                disabled={saving || !inputId}
                className="flex-1 bg-green-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-green-700 disabled:opacity-50"
              >
                {saving ? '保存中...' : '保存する'}
              </button>
              <button
                onClick={() => setEditMode(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium"
              >
                キャンセル
              </button>
            </div>
          </div>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => setEditMode(true)}
              className="flex-1 bg-green-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-green-700"
            >
              {lineLinked ? 'IDを変更する' : 'LINE User IDを設定する'}
            </button>
            {lineLinked && (
              <button
                onClick={handleDisconnect}
                className="px-4 bg-red-50 text-red-600 py-2 rounded-lg text-sm font-medium hover:bg-red-100"
              >
                解除
              </button>
            )}
          </div>
        )}
      </div>

      {/* How to get LINE User ID */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 space-y-3">
        <h3 className="font-semibold text-gray-800">LINE User IDの取得方法</h3>
        <ol className="space-y-3 text-sm text-gray-600">
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-xs font-bold">1</span>
            <span>LINE Developersコンソールにアクセスし、Messaging APIチャンネルを作成します</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-xs font-bold">2</span>
            <span>友だち追加後、Webhookでユーザーのsource.userId（Uから始まる文字列）を取得します</span>
          </li>
          <li className="flex gap-3">
            <span className="flex-shrink-0 w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-xs font-bold">3</span>
            <span>取得したIDをこの画面で入力してください</span>
          </li>
        </ol>
        <a
          href="https://developers.line.biz/console/"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-sm text-green-600 hover:underline mt-2"
        >
          LINE Developersコンソール <ExternalLink size={14} />
        </a>
      </div>

      {/* Note */}
      <div className="bg-blue-50 rounded-xl p-4 text-sm text-blue-700">
        <p className="font-medium mb-1">⚙️ バックエンド連携について</p>
        <p>LINE通知の実際の送信には、バックエンドAPIキー（LINE Channel Access Token）の設定が必要です。管理者にご連絡ください。</p>
      </div>
    </div>
  );
}