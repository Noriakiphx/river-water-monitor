import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import WaterLevelBadge from '@/components/WaterLevelBadge';
import { Star, Bell, MapPin, ArrowLeft, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import { ja } from 'date-fns/locale';

export default function StationDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [station, setStation] = useState(null);
  const [logs, setLogs] = useState([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteId, setFavoriteId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [id, user]);

  const loadData = async () => {
    setLoading(true);
    const [stationData, logData] = await Promise.all([
      base44.entities.Station.filter({ id }),
      base44.entities.WaterLevelLog.filter({ stationId: id }),
    ]);
    const s = stationData[0];
    setStation(s);

    const sorted = logData.sort((a, b) => new Date(a.observedAt) - new Date(b.observedAt));
    setLogs(sorted.slice(-48)); // Last 48 data points

    if (user) {
      const favs = await base44.entities.FavoriteStation.filter({ userId: user.id, stationId: id });
      if (favs.length > 0) {
        setIsFavorite(true);
        setFavoriteId(favs[0].id);
      }
    }
    setLoading(false);
  };

  const toggleFavorite = async () => {
    if (!user) return;
    if (isFavorite && favoriteId) {
      await base44.entities.FavoriteStation.delete(favoriteId);
      setIsFavorite(false);
      setFavoriteId(null);
    } else {
      const fav = await base44.entities.FavoriteStation.create({ userId: user.id, stationId: id });
      setIsFavorite(true);
      setFavoriteId(fav.id);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!station) {
    return <div className="text-center py-12 text-gray-400">観測所が見つかりません</div>;
  }

  const currentLevel = logs.length > 0 ? logs[logs.length - 1].waterLevel : null;

  const chartData = logs.map(l => ({
    time: format(new Date(l.observedAt), 'HH:mm', { locale: ja }),
    level: l.waterLevel,
  }));

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      {/* Back */}
      <Link to="/search" className="flex items-center gap-1 text-blue-600 text-sm">
        <ArrowLeft size={16} /> 検索に戻る
      </Link>

      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">{station.stationName}</h1>
            <p className="text-blue-600 font-medium">{station.riverName}</p>
            <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
              <MapPin size={14} />
              {station.prefecture} {station.municipality}
            </div>
          </div>
          <button onClick={toggleFavorite} className="p-2">
            <Star
              size={24}
              className={isFavorite ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
            />
          </button>
        </div>

        {/* Current level */}
        <div className="mt-4 flex items-end gap-3">
          <div>
            <p className="text-sm text-gray-500">現在水位</p>
            <p className="text-4xl font-bold text-gray-900">
              {currentLevel != null ? currentLevel.toFixed(2) : '--'}
              <span className="text-xl font-normal text-gray-500 ml-1">m</span>
            </p>
          </div>
          <div className="mb-1">
            <WaterLevelBadge
              level={currentLevel}
              warningLevel={station.warningLevel}
              evacuationLevel={station.evacuationLevel}
              dangerLevel={station.dangerLevel}
            />
          </div>
        </div>

        {/* Threshold info */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          {station.warningLevel != null && (
            <div className="bg-yellow-50 rounded-lg p-2 text-center">
              <p className="text-xs text-yellow-700">氾濫注意</p>
              <p className="font-bold text-yellow-800">{station.warningLevel}m</p>
            </div>
          )}
          {station.evacuationLevel != null && (
            <div className="bg-orange-50 rounded-lg p-2 text-center">
              <p className="text-xs text-orange-700">避難判断</p>
              <p className="font-bold text-orange-800">{station.evacuationLevel}m</p>
            </div>
          )}
          {station.dangerLevel != null && (
            <div className="bg-red-50 rounded-lg p-2 text-center">
              <p className="text-xs text-red-700">氾濫危険</p>
              <p className="font-bold text-red-800">{station.dangerLevel}m</p>
            </div>
          )}
        </div>
      </div>

      {/* Chart */}
      {chartData.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp size={18} className="text-blue-600" />
            <h2 className="font-semibold text-gray-800">水位推移</h2>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
              <YAxis tick={{ fontSize: 11 }} domain={['auto', 'auto']} />
              <Tooltip
                formatter={(v) => [`${v.toFixed(2)}m`, '水位']}
                labelStyle={{ fontSize: 12 }}
              />
              {station.warningLevel && (
                <ReferenceLine y={station.warningLevel} stroke="#eab308" strokeDasharray="4 4" label={{ value: '注意', fontSize: 11 }} />
              )}
              {station.evacuationLevel && (
                <ReferenceLine y={station.evacuationLevel} stroke="#f97316" strokeDasharray="4 4" label={{ value: '避難', fontSize: 11 }} />
              )}
              {station.dangerLevel && (
                <ReferenceLine y={station.dangerLevel} stroke="#ef4444" strokeDasharray="4 4" label={{ value: '危険', fontSize: 11 }} />
              )}
              <Line type="monotone" dataKey="level" stroke="#2563eb" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Set alert */}
      <Link
        to={`/alerts?stationId=${id}`}
        className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700"
      >
        <Bell size={18} />
        この観測所の通知を設定する
      </Link>
    </div>
  );
}