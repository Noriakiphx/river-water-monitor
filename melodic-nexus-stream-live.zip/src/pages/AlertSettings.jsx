import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Bell, Plus, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';

const THRESHOLD_TYPES = [
  { value: 'warning', label: '氾濫注意水位', color: 'text-yellow-600' },
  { value: 'evacuation', label: '避難判断水位', color: 'text-orange-600' },
  { value: 'danger', label: '氾濫危険水位', color: 'text-red-600' },
  { value: 'custom', label: '任意水位', color: 'text-blue-600' },
];

export default function AlertSettings() {
  const { user } = useAuth();
  const [rules, setRules] = useState([]);
  const [stations, setStations] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ stationId: '', thresholdType: 'warning', thresholdValue: '', cooldownMinutes: 60 });
  const [loading, setLoading] = useState(true);

  // Pre-select station from URL param
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const stationId = params.get('stationId');
    if (stationId) {
      setForm(f => ({ ...f, stationId }));
      setShowForm(true);
    }
  }, []);

  useEffect(() => {
    if (user) loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    const [ruleData, stationData] = await Promise.all([
      base44.entities.WatchRule.filter({ userId: user.id }),
      base44.entities.Station.list('-created_date', 200),
    ]);
    setRules(ruleData);
    setStations(stationData);
    setLoading(false);
  };

  const stationMap = Object.fromEntries(stations.map(s => [s.id, s]));

  const handleSave = async () => {
    if (!form.stationId || !form.thresholdType) return;
    await base44.entities.WatchRule.create({
      userId: user.id,
      stationId: form.stationId,
      thresholdType: form.thresholdType,
      thresholdValue: form.thresholdType === 'custom' ? parseFloat(form.thresholdValue) : null,
      cooldownMinutes: parseInt(form.cooldownMinutes) || 60,
      enabled: true,
    });
    setShowForm(false);
    setForm({ stationId: '', thresholdType: 'warning', thresholdValue: '', cooldownMinutes: 60 });
    loadData();
  };

  const toggleRule = async (rule) => {
    await base44.entities.WatchRule.update(rule.id, { enabled: !rule.enabled });
    setRules(prev => prev.map(r => r.id === rule.id ? { ...r, enabled: !r.enabled } : r));
  };

  const deleteRule = async (rule) => {
    if (!confirm('この通知設定を削除しますか？')) return;
    await base44.entities.WatchRule.delete(rule.id);
    setRules(prev => prev.filter(r => r.id !== rule.id));
  };

  const thresholdLabel = (rule) => {
    const t = THRESHOLD_TYPES.find(t => t.value === rule.thresholdType);
    if (rule.thresholdType === 'custom') return `任意水位 ${rule.thresholdValue}m`;
    const s = stationMap[rule.stationId];
    const levels = { warning: s?.warningLevel, evacuation: s?.evacuationLevel, danger: s?.dangerLevel };
    const level = levels[rule.thresholdType];
    return `${t?.label || rule.thresholdType}${level != null ? ` (${level}m)` : ''}`;
  };

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-gray-900">通知設定</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-1 bg-blue-600 text-white text-sm px-3 py-2 rounded-lg hover:bg-blue-700"
        >
          <Plus size={16} /> 追加
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 space-y-3">
          <h2 className="font-semibold text-gray-800">新しい通知条件</h2>
          <div>
            <label className="text-sm text-gray-600 block mb-1">観測所</label>
            <select
              value={form.stationId}
              onChange={e => setForm(f => ({ ...f, stationId: e.target.value }))}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
            >
              <option value="">選択してください</option>
              {stations.map(s => (
                <option key={s.id} value={s.id}>
                  {s.stationName}（{s.riverName}）
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-gray-600 block mb-1">通知条件</label>
            <select
              value={form.thresholdType}
              onChange={e => setForm(f => ({ ...f, thresholdType: e.target.value }))}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
            >
              {THRESHOLD_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </div>
          {form.thresholdType === 'custom' && (
            <div>
              <label className="text-sm text-gray-600 block mb-1">任意水位 (m)</label>
              <input
                type="number"
                step="0.01"
                value={form.thresholdValue}
                onChange={e => setForm(f => ({ ...f, thresholdValue: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
                placeholder="例: 2.50"
              />
            </div>
          )}
          <div>
            <label className="text-sm text-gray-600 block mb-1">クールダウン (分)</label>
            <input
              type="number"
              value={form.cooldownMinutes}
              onChange={e => setForm(f => ({ ...f, cooldownMinutes: e.target.value }))}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
              placeholder="60"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={!form.stationId}
              className="flex-1 bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
            >
              保存する
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium"
            >
              キャンセル
            </button>
          </div>
        </div>
      )}

      {/* Rules list */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
        </div>
      ) : rules.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
          <Bell size={40} className="text-gray-300 mx-auto mb-2" />
          <p className="text-gray-500 text-sm">通知設定がありません</p>
        </div>
      ) : (
        <div className="space-y-3">
          {rules.map(rule => {
            const s = stationMap[rule.stationId];
            const t = THRESHOLD_TYPES.find(t => t.value === rule.thresholdType);
            return (
              <div key={rule.id} className={`bg-white rounded-xl shadow-sm border p-4 ${rule.enabled ? 'border-gray-100' : 'border-gray-200 opacity-60'}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{s?.stationName || '不明な観測所'}</p>
                    <p className="text-sm text-blue-600">{s?.riverName}</p>
                    <p className={`text-sm mt-1 ${t?.color || 'text-gray-600'}`}>
                      {thresholdLabel(rule)}
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">クールダウン: {rule.cooldownMinutes}分</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => toggleRule(rule)}>
                      {rule.enabled
                        ? <ToggleRight size={28} className="text-blue-600" />
                        : <ToggleLeft size={28} className="text-gray-400" />
                      }
                    </button>
                    <button onClick={() => deleteRule(rule)} className="p-1">
                      <Trash2 size={16} className="text-gray-400 hover:text-red-500" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}