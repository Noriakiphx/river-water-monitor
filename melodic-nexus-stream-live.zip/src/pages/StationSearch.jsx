import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import StationCard from '@/components/StationCard';
import { Search, Filter } from 'lucide-react';

export default function StationSearch() {
  const { user } = useAuth();
  const [stations, setStations] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [latestLevels, setLatestLevels] = useState({});
  const [query, setQuery] = useState('');
  const [prefecture, setPrefecture] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    const [allStations, favs, logs] = await Promise.all([
      base44.entities.Station.list('-created_date', 200),
      user ? base44.entities.FavoriteStation.filter({ userId: user.id }) : [],
      base44.entities.WaterLevelLog.list('-observedAt', 500),
    ]);
    setStations(allStations);
    setFavorites(favs);
    const levelMap = {};
    logs.forEach(log => {
      if (!levelMap[log.stationId]) levelMap[log.stationId] = log.waterLevel;
    });
    setLatestLevels(levelMap);
    setLoading(false);
  };

  const toggleFavorite = async (station) => {
    if (!user) return;
    const existing = favorites.find(f => f.stationId === station.id);
    if (existing) {
      await base44.entities.FavoriteStation.delete(existing.id);
      setFavorites(prev => prev.filter(f => f.id !== existing.id));
    } else {
      const fav = await base44.entities.FavoriteStation.create({ userId: user.id, stationId: station.id });
      setFavorites(prev => [...prev, fav]);
    }
  };

  const prefectures = [...new Set(stations.map(s => s.prefecture).filter(Boolean))].sort();

  const filtered = stations.filter(s => {
    const q = query.toLowerCase();
    const matchQuery = !q || 
      s.stationName?.toLowerCase().includes(q) || 
      s.riverName?.toLowerCase().includes(q) ||
      s.municipality?.toLowerCase().includes(q);
    const matchPref = !prefecture || s.prefecture === prefecture;
    return matchQuery && matchPref;
  });

  const favStationIds = new Set(favorites.map(f => f.stationId));

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      <h1 className="text-xl font-bold text-gray-900">観測所検索</h1>

      {/* Search bar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 space-y-3">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="観測所名・河川名で検索"
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:border-blue-400 focus:outline-none text-sm"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-gray-400" />
          <select
            value={prefecture}
            onChange={e => setPrefecture(e.target.value)}
            className="flex-1 py-2 px-3 rounded-lg border border-gray-200 focus:border-blue-400 focus:outline-none text-sm"
          >
            <option value="">都道府県（全て）</option>
            {prefectures.map(p => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Results */}
      <div>
        <p className="text-sm text-gray-500 mb-3">{filtered.length}件の観測所</p>
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <Search size={40} className="mx-auto mb-2 opacity-40" />
            <p>観測所が見つかりませんでした</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map(s => (
              <StationCard
                key={s.id}
                station={s}
                currentLevel={latestLevels[s.id]}
                isFavorite={favStationIds.has(s.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}