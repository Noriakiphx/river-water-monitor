import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Navigate } from 'react-router-dom';
import { Shield, Radio, Bell, Database, Plus, Trash2, Edit2, X, Check } from 'lucide-react';
import { format } from 'date-fns';
import { ja } from 'date-fns/locale';

const TABS = ['観測所管理', 'API状況', '通知ログ'];

export default function AdminPanel() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(0);
  const [stations, setStations] = useState([]);
  const [notifLogs, setNotifLogs] = useState([]);
  const [waterLogs, setWaterLogs] = useState([]);
  const [showStationForm, setShowStationForm] = useState(false);
  const [editStation, setEditStation] = useState(null);
  const [form, setForm] = useState({
    riverName: '', stationName: '', prefecture: '', municipality: '',
    lat: '', lng: '', observationCode: '',
    warningLevel: '', evacuationLevel: '', dangerLevel: ''
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  if (user && user.role !== 'admin') return <Navigate to="/" replace />;

  const loadData = async () => {
    setLoading(true);
    const [s, nl, wl] = await Promise.all([
      base44.entities.Station.list('-created_date', 100),
      base44.entities.NotificationLog.list('-sentAt', 100),
      base44.entities.WaterLevelLog.list('-observedAt', 200),
    ]);
    setStations(s);
    setNotifLogs(nl);
    setWaterLogs(wl);
    setLoading(false);
  };

  const openCreateForm = () => {
    setEditStation(null);
    setForm({ riverName: '', stationName: '', prefecture: '', municipality: '', lat: '', lng: '', observationCode: '', warningLevel: '', evacuationLevel: '', dangerLevel: '' });
    setShowStationForm(true);
  };

  const openEditForm = (s) => {
    setEditStation(s);
    setForm({
      riverName: s.riverName || '', stationName: s.stationName || '',
      prefecture: s.prefecture || '', municipality: s.municipality || '',
      lat: s.lat ?? '', lng: s.lng ?? '', observationCode: s.observationCode || '',
      warningLevel: s.warningLevel ?? '', evacuationLevel: s.evacuationLevel ?? '', dangerLevel: s.dangerLevel ?? ''
    });
    setShowStationForm(true);
  };

  const handleSaveStation = async () => {
    const data = {
      riverName: form.riverName, stationName: form.stationName,
      prefecture: form.prefecture, municipality: form.municipality,
      lat: form.lat ? parseFloat(form.lat) : null,
      lng: form.lng ? parseFloat(form.lng) : null,
      observationCode: form.observationCode,
      warningLevel: form.warningLevel ? parseFloat(form.warningLevel) : null,
      evacuationLevel: form.evacuationLevel ? parseFloat(form.evacuationLevel) : null,
      dangerLevel: form.dangerLevel ? parseFloat(form.dangerLevel) : null,
    };
    if (editStation) {
      await base44.entities.Station.update(editStation.id, data);
    } else {
      await base44.entities.Station.create(data);
    }
    setShowStationForm(false);
    loadData();
  };

  const deleteStation = async (id) => {
    if (!confirm('この観測所を削除しますか？')) return;
    await base44.entities.Station.delete(id);
    setStations(prev => prev.filter(s => s.id !== id));
  };

  const generateDummyData = async () => {
    if (!confirm('選択した観測所にダミー水位データを生成しますか？')) return;
    const now = new Date();
    const entries = [];
    stations.forEach(s => {
      for (let i = 47; i >= 0; i--) {
        const t = new Date(now.getTime() - i * 30 * 60 * 1000);
        const base = (s.warningLevel || 1.5) * 0.7;
        const variation = (Math.random() - 0.3) * 0.5;
        entries.push({
          stationId: s.id,
          observedAt: t.toISOString(),
          waterLevel: Math.max(0, parseFloat((base + variation).toFixed(2))),
          source: 'dummy',
        });
      }
    });
    await base44.entities.WaterLevelLog.bulkCreate(entries);
    alert('ダミーデータを生成しました');
    loadData();
  };

  const stationMap = Object.fromEntries(stations.map(s => [s.id, s]));

  return (
    <div className="pb-20 md:pb-6 md:ml-48 space-y-4">
      <div className="flex items-center gap-2">
        <Shield size={20} className="text-blue-600" />
        <h1 className="text-xl font-bold text-gray-900">管理者画面</h1>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-100 rounded-xl p-1">
        {TABS.map((tab, i) => (
          <button
            key={tab}
            onClick={() => setActiveTab(i)}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeTab === i ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab: 観測所管理 */}
      {activeTab === 0 && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <button onClick={openCreateForm} className="flex items-center gap-1 bg-blue-600 text-white text-sm px-3 py-2 rounded-lg hover:bg-blue-700">
              <Plus size={16} /> 観測所追加
            </button>
            <button onClick={generateDummyData} className="flex items-center gap-1 bg-gray-600 text-white text-sm px-3 py-2 rounded-lg hover:bg-gray-700">
              <Database size={16} /> ダミーデータ生成
            </button>
          </div>

          {showStationForm && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{editStation ? '観測所編集' : '観測所追加'}</h3>
                <button onClick={() => setShowStationForm(false)}><X size={18} className="text-gray-400" /></button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { key: 'riverName', label: '河川名', required: true },
                  { key: 'stationName', label: '観測所名', required: true },
                  { key: 'prefecture', label: '都道府県' },
                  { key: 'municipality', label: '市区町村' },
                  { key: 'observationCode', label: '観測所コード' },
                  { key: 'lat', label: '緯度', type: 'number' },
                  { key: 'lng', label: '経度', type: 'number' },
                  { key: 'warningLevel', label: '氾濫注意水位(m)', type: 'number' },
                  { key: 'evacuationLevel', label: '避難判断水位(m)', type: 'number' },
                  { key: 'dangerLevel', label: '氾濫危険水位(m)', type: 'number' },
                ].map(field => (
                  <div key={field.key}>
                    <label className="text-xs text-gray-600 block mb-1">{field.label}</label>
                    <input
                      type={field.type || 'text'}
                      step={field.type === 'number' ? '0.01' : undefined}
                      value={form[field.key]}
                      onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))}
                      className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-sm focus:border-blue-400 focus:outline-none"
                    />
                  </div>
                ))}
              </div>
              <div className="flex gap-2 pt-1">
                <button onClick={handleSaveStation} className="flex-1 bg-blue-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
                  保存
                </button>
                <button onClick={() => setShowStationForm(false)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium">
                  キャンセル
                </button>
              </div>
            </div>
          )}

          {loading ? (
            <div className="flex justify-center py-8"><div className="w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin" /></div>
          ) : (
            <div className="space-y-2">
              {stations.map(s => (
                <div key={s.id} className="bg-white rounded-xl border border-gray-100 p-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm text-gray-900">{s.stationName}</p>
                    <p className="text-xs text-blue-600">{s.riverName} / {s.prefecture}</p>
                    <p className="text-xs text-gray-400">
                      注意:{s.warningLevel ?? '--'}m 避難:{s.evacuationLevel ?? '--'}m 危険:{s.dangerLevel ?? '--'}m
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => openEditForm(s)} className="p-1 text-gray-400 hover:text-blue-600">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => deleteStation(s.id)} className="p-1 text-gray-400 hover:text-red-500">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: API状況 */}
      {activeTab === 1 && (
        <div className="space-y-3">
          <div className="bg-white rounded-xl border border-gray-100 p-4">
            <div className="flex items-center gap-2 mb-3">
              <Radio size={18} className="text-blue-600" />
              <h3 className="font-semibold text-gray-800">データ取得状況</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-gray-900">{stations.length}</p>
                <p className="text-xs text-gray-500">登録観測所数</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-gray-900">{waterLogs.length}</p>
                <p className="text-xs text-gray-500">水位データ件数</p>
              </div>
            </div>
          </div>
          <div className="bg-yellow-50 rounded-xl p-4 text-sm text-yellow-800">
            <p className="font-medium mb-1">⚙️ 外部API接続</p>
            <p>国土交通省 川の防災情報APIへの接続はBackend Functionsで実装可能です。現在はダミーデータモードで動作中です。</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 p-4">
            <h3 className="font-semibold text-gray-800 mb-3">最新水位データ</h3>
            <div className="space-y-2">
              {waterLogs.slice(0, 10).map(log => {
                const s = stationMap[log.stationId];
                return (
                  <div key={log.id} className="flex items-center justify-between text-sm border-b border-gray-50 pb-2">
                    <div>
                      <p className="font-medium text-gray-800">{s?.stationName || '不明'}</p>
                      <p className="text-xs text-gray-400">
                        {log.observedAt ? format(new Date(log.observedAt), 'MM/dd HH:mm', { locale: ja }) : '--'}
                      </p>
                    </div>
                    <p className="font-bold text-blue-700">{log.waterLevel}m</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab: 通知ログ */}
      {activeTab === 2 && (
        <div className="space-y-3">
          <div className="bg-white rounded-xl border border-gray-100 p-4">
            <div className="flex items-center gap-2 mb-3">
              <Bell size={18} className="text-blue-600" />
              <h3 className="font-semibold text-gray-800">通知送信ログ</h3>
            </div>
            {notifLogs.length === 0 ? (
              <p className="text-center text-gray-400 py-6 text-sm">通知ログはありません</p>
            ) : (
              <div className="space-y-2">
                {notifLogs.map(log => (
                  <div key={log.id} className="border border-gray-100 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        log.status === 'sent' ? 'bg-green-50 text-green-700' :
                        log.status === 'failed' ? 'bg-red-50 text-red-700' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {log.status === 'sent' ? '送信済' : log.status === 'failed' ? '失敗' : '保留中'}
                      </span>
                      <span className="text-xs text-gray-400">
                        {log.sentAt ? format(new Date(log.sentAt), 'MM/dd HH:mm', { locale: ja }) : '--'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{log.message}</p>
                    {log.errorMessage && (
                      <p className="text-xs text-red-500 mt-1">{log.errorMessage}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}