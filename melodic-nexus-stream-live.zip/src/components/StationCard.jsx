import { Link } from 'react-router-dom';
import { Star, MapPin } from 'lucide-react';
import WaterLevelBadge from './WaterLevelBadge';

export default function StationCard({ station, currentLevel, isFavorite, onToggleFavorite }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-gray-900 truncate">{station.stationName}</h3>
            <WaterLevelBadge
              level={currentLevel}
              warningLevel={station.warningLevel}
              evacuationLevel={station.evacuationLevel}
              dangerLevel={station.dangerLevel}
            />
          </div>
          <p className="text-sm text-blue-600 font-medium mt-0.5">{station.riverName}</p>
          <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
            <MapPin size={12} />
            {station.prefecture} {station.municipality}
          </div>
          {currentLevel != null && (
            <p className="text-lg font-bold text-gray-800 mt-2">
              {currentLevel.toFixed(2)} <span className="text-sm font-normal text-gray-500">m</span>
            </p>
          )}
        </div>
        <div className="flex flex-col items-end gap-2 ml-2">
          {onToggleFavorite && (
            <button onClick={() => onToggleFavorite(station)} className="p-1">
              <Star
                size={20}
                className={isFavorite ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
              />
            </button>
          )}
          <Link
            to={`/station/${station.id}`}
            className="text-xs bg-blue-600 text-white px-3 py-1 rounded-full hover:bg-blue-700"
          >
            詳細
          </Link>
        </div>
      </div>
    </div>
  );
}