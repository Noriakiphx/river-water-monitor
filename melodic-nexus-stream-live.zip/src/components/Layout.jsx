import { Link, Outlet, useLocation } from 'react-router-dom';
import { Home, Search, Bell, History, Link2, Shield, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';

const navItems = [
  { path: '/', label: 'ダッシュボード', icon: Home },
  { path: '/search', label: '観測所検索', icon: Search },
  { path: '/alerts', label: '通知設定', icon: Bell },
  { path: '/history', label: '通知履歴', icon: History },
  { path: '/line', label: 'LINE連携', icon: Link2 },
];

export default function Layout() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-blue-700 text-white shadow-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg flex items-center gap-2">
            🌊 河川水位監視
          </Link>
          <div className="flex items-center gap-2">
            {user?.role === 'admin' && (
              <Link to="/admin" className="text-blue-200 hover:text-white text-xs px-2 py-1 rounded border border-blue-400">
                管理者
              </Link>
            )}
            <button
              className="md:hidden p-1"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden bg-blue-800 px-4 pb-3 space-y-1">
            {navItems.map(item => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMenuOpen(false)}
                className={`flex items-center gap-2 px-3 py-2 rounded text-sm ${
                  location.pathname === item.path ? 'bg-blue-600 text-white' : 'text-blue-200 hover:text-white'
                }`}
              >
                <item.icon size={16} />
                {item.label}
              </Link>
            ))}
            <button
              onClick={() => { base44.auth.logout('/login'); }}
              className="w-full text-left text-blue-200 hover:text-white px-3 py-2 text-sm"
            >
              ログアウト
            </button>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-4">
        <Outlet />
      </main>

      {/* Bottom nav (mobile) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
        <div className="grid grid-cols-5">
          {navItems.map(item => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center py-2 text-xs gap-0.5 ${
                location.pathname === item.path ? 'text-blue-600' : 'text-gray-500'
              }`}
            >
              <item.icon size={20} />
              <span className="text-[10px]">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>

      {/* Desktop side nav */}
      <div className="hidden md:block fixed left-0 top-14 bottom-0 w-48 bg-white border-r border-gray-200 pt-4 z-30">
        <div className="space-y-1 px-3">
          {navItems.map(item => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${
                location.pathname === item.path
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <item.icon size={16} />
              {item.label}
            </Link>
          ))}
          {user?.role === 'admin' && (
            <Link
              to="/admin"
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${
                location.pathname === '/admin'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Shield size={16} />
              管理者画面
            </Link>
          )}
          <button
            onClick={() => base44.auth.logout('/login')}
            className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 mt-4"
          >
            ログアウト
          </button>
        </div>
      </div>
    </div>
  );
}