export default function WaterLevelBadge({ level, warningLevel, evacuationLevel, dangerLevel }) {
  if (level == null) return <span className="text-gray-400 text-sm">--</span>;

  let color = 'bg-blue-100 text-blue-700';
  let label = '平常';

  if (dangerLevel != null && level >= dangerLevel) {
    color = 'bg-red-600 text-white';
    label = '氾濫危険';
  } else if (evacuationLevel != null && level >= evacuationLevel) {
    color = 'bg-orange-500 text-white';
    label = '避難判断';
  } else if (warningLevel != null && level >= warningLevel) {
    color = 'bg-yellow-400 text-gray-900';
    label = '氾濫注意';
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${color}`}>
      {label}
    </span>
  );
}